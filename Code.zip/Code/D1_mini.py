import time
import math
import json
import machine
import network
from umqtt.simple import MQTTClient

# MQTT Credentials
mqtt_server = "broker.MQTTGO.io"
mqtt_port = 1883
mqtt_user = ""
mqtt_password = ""

# WiFi Credentials
ssid = ""
password = ""

# GPIO 設定
RED_PIN = 13 # GPIO13(D7)
GREEN_PIN = 15 # GPIO15(D8)
LDR_PIN = 0 # A0

red_led = machine.Pin(RED_PIN, machine.Pin.OUT)
green_led = machine.Pin(GREEN_PIN, machine.Pin.OUT)
ldr = machine.ADC(LDR_PIN)

# MQTT Topics
TOPIC_STATUS = "nfu/group5/traffic/light/status"
TOPIC_CONTROL = "nfu/group5/traffic/light/control"

# 初始狀態
current_light = "red"
red_duration = 10 # 初始紅燈時間
green_base = 7 # 初始綠燈時間
green_extend = 0 # 初始綠燈延長時間
std_deviation = 0

# 連接 WiFi
def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(ssid, password)

    while not wlan.isconnected():
        print("Connecting to WiFi...")
        time.sleep(1)

    print("WiFi connected")

# 連接到 MQTT 伺服器
def connect_mqtt():
    try:
        client_id = "D1Mini_" + str(machine.unique_id())
        client = MQTTClient(client_id, mqtt_server, mqtt_port)
        client.set_callback(on_message)
        client.connect()
        client.subscribe(TOPIC_CONTROL)
        print("已成功訂閱主題: {}".format(TOPIC_CONTROL))
        return client
    except Exception as e:
        print("MQTT 連接失敗: {}".format(e))
        return None

# 處理 MQTT 訊息
def on_message(topic, msg):
    global current_light
    try:
        print("收到訊息 Topic: {}, Payload: {}".format(topic.decode('utf-8'), msg.decode('utf-8')))
        if topic.decode('utf-8') == TOPIC_CONTROL:
            message = json.loads(msg.decode('utf-8'))
            control = message.get("control", "")
            if control == "red":
                switch_to_red()
            elif control == "green":
                switch_to_green()
            elif control == "state":
                report_status(mqtt_client)
            else:
                print("未知的控制訊息: {}".format(control))
    except Exception as e:
        print("處理 MQTT 訊息時發生錯誤: {}".format(e))

# 切換至紅燈
def switch_to_red():
    """切換至紅燈"""
    global current_light, std_deviation
    std_deviation = 0
    red_led.on()
    green_led.off()
    current_light = "red"
    print("紅燈亮起，持續時間: {} 秒".format(red_duration))
    time.sleep(red_duration)

# 切換至綠燈
def switch_to_green():
    """切換至綠燈並測量車流量"""
    global current_light, green_base, green_extend, std_deviation
    red_led.off()
    green_led.on()
    current_light = "green"
    print("綠燈亮起，初始時間: {} 秒".format(green_base))
    std_deviation = measure_flow_during_green(7)
    decide_green_extend(std_deviation)
    time.sleep(green_extend)

# 測量車流量
def measure_flow_during_green(duration, interval=1):
    """光敏電阻值的標準差"""
    values = []
    for _ in range(duration):
        values.append(ldr.read())
        time.sleep(interval)
    avg_value = sum(values) / len(values)
    std_deviation = math.sqrt(sum((x - avg_value) ** 2 for x in values) / len(values))
    print("光敏電阻標準差: {:.2f}".format(std_deviation))
    return std_deviation

# 決定綠燈延長時間
def decide_green_extend(std_deviation):
    """根據測量的標準差來決定當前綠燈時間是否延長"""
    global green_extend
    if std_deviation >= 5: # 高標準差：延長 10 秒，共 17 秒
        green_extend = 10
    elif std_deviation >= 2: # 中等標準差：延長 5 秒，共 12 秒
        green_extend = 5
    else: # 低標準差：不延長，保持 7 秒
        green_extend = 0
    print("延長的綠燈時間: {} 秒".format(green_extend))

# 回報燈號狀態
def report_status(client):
    try:
        message = json.dumps({
            "status": current_light,
            "car_flow": std_deviation
        })
        client.publish(TOPIC_STATUS, message)
        print("狀態已回報: {}".format(message))
    except Exception as e:
        print("錯誤 - 回報狀態時發生問題: {}".format(str(e)))

# 主程式迴圈
def main_loop():
    """主程式執行迴圈"""
    while True:
        mqtt_client.check_msg() # 處理 MQTT 消息
        if current_light == "red":
            switch_to_green()
        elif current_light == "green":
            switch_to_red()

# 主程式 entry
try:
    connect_wifi()

    # MQTT 連接
    mqtt_client = connect_mqtt()
    if mqtt_client is None:
        print("MQTT 連接失敗，重新嘗試中...")
        mqtt_client = connect_mqtt()

    while mqtt_client:
        main_loop()

except KeyboardInterrupt:
    print("程式終止")