import os
import json
import time
from phi.agent import Agent
import paho.mqtt.client as mqtt
from phi.model.openai import OpenAIChat

# 環境變數設置
os.environ["OPENAI_API_KEY"] = ""

# MQTT 設置
MQTT_BROKER = "broker.MQTTGO.io"
MQTT_PORT = 1883
MQTT_USER = ""
MQTT_PASSWORD = ""

TOPIC_STATUS = "nfu/group5/traffic/light/status"
TOPIC_CONTROL = "nfu/group5/traffic/light/control"

def state_report():
    try:
        client = mqtt.Client()
        client.username_pw_set(MQTT_USER, MQTT_PASSWORD)
        client.connect(MQTT_BROKER, MQTT_PORT, 60)

        messages = []

        def on_message(client, userdata, msg):
            messages.append(json.loads(msg.payload.decode('utf-8')))

        client.subscribe(TOPIC_STATUS)
        client.on_message = on_message

        client.loop_start()
        timeout = 10
        for _ in range(timeout):
            if messages:
                break
            time.sleep(1)
        client.loop_stop()

        client.disconnect()

        if messages:
            return json.dumps(messages[0], ensure_ascii = False)
        else:
            return json.dumps({"error": "未收到任何訊息"}, ensure_ascii = False)

    except Exception as e:
        print(f"Debug - MQTT Error: {str(e)}")
        return f"無法獲取燈號及車流狀態: {str(e)}"

def control_signal(control: str):
    try:
        client = mqtt.Client()
        client.username_pw_set(MQTT_USER, MQTT_PASSWORD)
        client.connect(MQTT_BROKER, MQTT_PORT, 60)

        client.loop_start()
        time.sleep(1)
        client.loop_stop()

        message = json.dumps({"control": control})
        result = client.publish(TOPIC_CONTROL, message)

        client.disconnect()

        if result.rc != mqtt.MQTT_ERR_SUCCESS:
            print(f"Debug - MQTT Publish failed: {result.rc}")
            return "燈號控制失敗"

        return f"成功發送控制指令: {message}"

    except Exception as e:
        print(f"Debug - MQTT Error: {str(e)}")
        return f"燈號控制失敗: {str(e)}"

state_agent = Agent(
    name = "State Report Agent",
    role = "回報燈號、車流量狀態",
    instructions = [
        "1. 使用 state_report 工具進行燈號、車流量狀態回報",
        "2. 返回操作結果",
        "3. 如果 car_flow >= 5，是高車流量; 5 > car_flow >= 2，是中車流量; car_flow < 2，是低車流量",
        "4. 如果返回的結果是 red ，則現在燈號是綠燈; 如果返回的結果是 green ，則現在燈號是紅燈;",
        "5. 車流量的狀況是上個燈號的車流量",
    ],
    tools = [state_report]
)

control_agent = Agent(
    name = "Control Agent",
    role = "發送控制燈號請求及資訊回報請求",
    instructions = [
        "1. 使用 control_signal 工具發送燈號控制及資訊回報請求",
        "2. 返回操作結果",
        "3. 可選控制指令: 'red', 'green', 'state'",
        "4. 確保訊息正確地被發佈到 TOPIC_CONTROL",
        "5. 如果要請求目前燈號等狀態，則發布 {""control"": ""state""}",
        "6. 如果要請求改成紅燈，則發布 {""control"": ""red""}",
        "7. 如果要請求改成綠燈，則發布 {""control"": ""green""}",
    ],
    tools = [control_signal]
)

def introduce_self():
    """自我介紹"""
    return """
    大家好！我是一個智能助理，我可以：
    1. 控制紅綠燈的燈號
    2. 理解自然語言指令
    3. 幫助您更方便地操作智能設備
    4. 提供您燈號及車流量等訊息
    """

intro_agent = Agent(
    name = "Introduction Agent",
    role = "進行自我介紹",
    instructions = [
        "1. 使用 introduce_self 工具進行自我介紹",
        "2. 提供友善且專業的介紹"
    ],
    tools = [introduce_self]
)

agent_team = Agent(
    model = OpenAIChat(id = "gpt-4o"),
    name = "智能助理團隊",
    team = [intro_agent, control_agent, state_agent],
    instructions = [
        "1. 識別用戶需求選擇合適的 agent",
        "2. 立即執行相對應操作",
        "3. 返回操作結果",
        "4. 使用中文回應",
        "5. 確保操作的實際執行",
        "6. 如果要自我介紹，用 intro_agent",
        "7. 如果要發送燈號控制請求或資訊請求，用 control_agent",
        "8. 如果要回報燈號或車流量狀態，用 control_agent 請求完資訊後，再用 state_agent 回報",
    ],
    show_tool_calls = True
)

def main():
    print("智能助理已啟動！(輸入 'exit' 結束程式)")
    print("您可以：")
    print("1. 查看自我介紹 (輸入：'自我介紹')")
    print("2. 控制燈號 (例如：'red', 'green', 'state') (可能無法同步)")
    print("3. 查詢燈號及車流量 (可能無法同步)")

    while True:
        user_input = input("\n請輸入指令: ").strip()
        if user_input.lower() == 'exit':
            print("程式已結束")
            break
        try:
            response = agent_team.run(user_input, stream = False)

            for message in response.messages:
                if message.role == "assistant" and message.content:
                    print("\n助理回應:", message.content.strip())

        except Exception as e:
            print(f"\n錯誤：{str(e)}")

if __name__ == "__main__":
    main()